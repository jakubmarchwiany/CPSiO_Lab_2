import exercise3
import exercise4

global file_path

import exercise1

import exercise2

def print_menu():
    print("----------------------------------\n"
          "---------------Menu---------------\n"
          "----------------------------------\n"
          "[0] Zamknij program\n"
          "[1] Menu Ekg1\n"
          "[2] Menu Ekg100\n"
          "[3] Menu Ekg_noise")


def menu():
    global file_path
    while True:
        print_menu()
        choose = float(input("Twój wybór : "))

        if choose == 0:
            break
        elif choose == 1:
            file_path = exercise1.read_ekg1()
        elif choose == 2:
            file_path = exercise1.read_ekg100()
        elif choose == 3:
            file_path = exercise1.read_ekg_noise()
        else:
            print("nie ma takiego wyboru")


if __name__ == '__main__':
    # exercise2.generate_sine_wave()
    #
    # # file_path = exercise1.test()
    # # file_path = exercise1.read_ekg1()
    # exercise2.generate_sine_wave()

    menu()
